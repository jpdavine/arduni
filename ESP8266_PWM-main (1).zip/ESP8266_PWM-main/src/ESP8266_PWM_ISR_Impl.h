/****************************************************************************************************************************
  ESP8266_PWM_ISR_Impl.h
  For ESP8266 boards
  Written by Khoi Hoang

  Built by Khoi Hoang https://github.com/khoih-prog/ESP8266_PWM
  Licensed under MIT license

  The ESP8266 timers are badly designed, using only 23-bit counter along with maximum 256 prescaler. They're only better than UNO / Mega.
  The ESP8266 has two hardware timers, but timer0 has been used for WiFi and it's not advisable to use. Only timer1 is available.
  The timer1's 23-bit counter terribly can count only up to 8,388,607. So the timer1 maximum interval is very short.
  Using 256 prescaler, maximum timer1 interval is only 26.843542 seconds !!!

  Now with these new 16 ISR-based timers, the maximum interval is practically unlimited (limited only by unsigned long miliseconds)
  The accuracy is nearly perfect compared to software timers. The most important feature is they're ISR-based timers
  Therefore, their executions are not blocked by bad-behaving functions / tasks.
  This important feature is absolutely necessary for mission-critical tasks.

  Version: 1.2.4

  Version Modified By   Date      Comments
  ------- -----------  ---------- -----------
  1.0.0   K Hoang      21/09/2021 Initial coding for ESP8266 boards with ESP8266 core v3.0.2+
  1.1.0   K Hoang      06/11/2021 Add functions to modify PWM settings on-the-fly
  1.2.0   K Hoang      29/01/2022 Fix multiple-definitions linker error. Improve accuracy
  1.2.1   K Hoang      30/01/2022 Fix bug. Optimize code
  1.2.2   K Hoang      30/01/2022 DutyCycle to be updated at the end current PWM period
  1.2.3   K Hoang      01/02/2022 Use float for DutyCycle and Freq, uint32_t for period
  1.2.4   K Hoang      04/03/2022 Fix `DutyCycle` and `New Period` display bugs. Display warning only when debug level > 3
*****************************************************************************************************************************/

#pragma once

#ifndef PWM_ISR_GENERIC_IMPL_H
#define PWM_ISR_GENERIC_IMPL_H

#include <string.h>

///////////////////////////////////////////////////


uint64_t timeNow()
{
#if USING_MICROS_RESOLUTION
  return ( (uint64_t) micros() );
#else
  return ( (uint64_t) millis() );
#endif
}

///////////////////////////////////////////////////

ESP8266_PWM_ISR::ESP8266_PWM_ISR()
  : numChannels (-1)
{
}

///////////////////////////////////////////////////

void ESP8266_PWM_ISR::init()
{
  uint64_t currentTime = timeNow();

  for (uint8_t channelNum = 0; channelNum < MAX_NUMBER_CHANNELS; channelNum++)
  {
    memset((void*) &PWM[channelNum], 0, sizeof (PWM_t));
    PWM[channelNum].prevTime = currentTime;
    PWM[channelNum].pin      = INVALID_ESP8266_PIN;
  }

  numChannels = 0;
}

///////////////////////////////////////////////////

void IRAM_ATTR ESP8266_PWM_ISR::run()
{
  uint64_t currentTime = timeNow();

  for (uint8_t channelNum = 0; channelNum < MAX_NUMBER_CHANNELS; channelNum++)
  {
    // If enabled => check
    // start period / dutyCycle => digitalWrite HIGH
    // end dutyCycle =>  digitalWrite LOW
    if (PWM[channelNum].enabled)
    {
      if ( (uint32_t) (currentTime - PWM[channelNum].prevTime) <= PWM[channelNum].onTime )
      {
        if (!PWM[channelNum].pinHigh)
        {
          digitalWrite(PWM[channelNum].pin, HIGH);
          PWM[channelNum].pinHigh = true;

          // callback when PWM pulse starts (HIGH)
          if (PWM[channelNum].callbackStart != nullptr)
          {
            (*(esp8266_timer_callback) PWM[channelNum].callbackStart)();
          }
        }
      }
      else if ( (uint32_t) (currentTime - PWM[channelNum].prevTime) < PWM[channelNum].period )
      {
        if (PWM[channelNum].pinHigh)
        {
          digitalWrite(PWM[channelNum].pin, LOW);
          PWM[channelNum].pinHigh = false;

          // callback when PWM pulse stops (LOW)
          if (PWM[channelNum].callbackStop != nullptr)
          {
            (*(esp8266_timer_callback) PWM[channelNum].callbackStop)();
          }
        }
      }
      //else
      else if ( (uint32_t) (currentTime - PWM[channelNum].prevTime) >= PWM[channelNum].period )
      {
        PWM[channelNum].prevTime = currentTime;

#if CHANGING_PWM_END_OF_CYCLE

        // Only update whenever having newPeriod
        if (PWM[channelNum].newPeriod != 0)
        {
          PWM[channelNum].period    = PWM[channelNum].newPeriod;
          PWM[channelNum].newPeriod = 0;

          PWM[channelNum].onTime  = PWM[channelNum].newOnTime;
        }

#endif
      }
    }
  }
}


///////////////////////////////////////////////////

// find the first available slot
// return -1 if none found
int ESP8266_PWM_ISR::findFirstFreeSlot()
{
  // all slots are used
  if (numChannels >= MAX_NUMBER_CHANNELS)
  {
    return -1;
  }

  // return the first slot with zero period and not enabled (i.e. free)
  for (uint8_t channelNum = 0; channelNum < MAX_NUMBER_CHANNELS; channelNum++)
  {
    if ( (PWM[channelNum].period == 0) && !PWM[channelNum].enabled )
    {
      return channelNum;
    }
  }

  // no free slots found
  return -1;
}

///////////////////////////////////////////////////

// Return the channelNum if OK, -1 if error
int ESP8266_PWM_ISR::setupPWMChannel(const uint32_t& pin, const uint32_t& period, const float& dutycycle,
                                     void* cbStartFunc, void* cbStopFunc)
{
  int channelNum;

  // Invalid input, such as period = 0, etc
  if ( (period == 0) || (dutycycle < 0.0) || (dutycycle > 100.0) )
  {
    PWM_LOGERROR("Error: Invalid period or dutycycle");
    return -1;
  }

  if (numChannels < 0)
  {
    init();
  }

  channelNum = findFirstFreeSlot();

  if (channelNum < 0)
  {
    return -1;
  }

  PWM[channelNum].pin           = pin;
  PWM[channelNum].period        = period;

  // Must be 0 for new PWM channel
  PWM[channelNum].newPeriod     = 0;

  PWM[channelNum].onTime        = ( period * dutycycle ) / 100;

  pinMode(pin, OUTPUT);
  digitalWrite(pin, HIGH);
  PWM[channelNum].pinHigh       = true;

  PWM[channelNum].prevTime      = timeNow();

  PWM[channelNum].callbackStart = cbStartFunc;
  PWM[channelNum].callbackStop  = cbStopFunc;

  PWM_LOGINFO0("Channel : ");
  PWM_LOGINFO0(channelNum);
  PWM_LOGINFO0("\t    Period : ");
  PWM_LOGINFO0(PWM[channelNum].period);
  PWM_LOGINFO0("\t\tOnTime : ");
  PWM_LOGINFO0(PWM[channelNum].onTime);
  PWM_LOGINFO0("\tStart_Time : ");
  PWM_LOGINFOLN0(PWM[channelNum].prevTime);

  numChannels++;

  PWM[channelNum].enabled      = true;

  return channelNum;
}

///////////////////////////////////////////////////

bool ESP8266_PWM_ISR::modifyPWMChannel_Period(const uint8_t& channelNum, const uint32_t& pin, const uint32_t& period,
                                              const float& dutycycle)
{
  // Invalid input, such as period = 0, etc
  if ( (period == 0) || (dutycycle < 0.0) || (dutycycle > 100.0) )
  {
    PWM_LOGERROR("Error: Invalid period or dutycycle");
    return false;
  }

  if (channelNum > MAX_NUMBER_CHANNELS)
  {
    PWM_LOGERROR("Error: channelNum > MAX_NUMBER_CHANNELS");
    return false;
  }

  if (PWM[channelNum].pin != pin)
  {
    PWM_LOGERROR("Error: channelNum and pin mismatched");
    return false;
  }

#if CHANGING_PWM_END_OF_CYCLE

  PWM[channelNum].newPeriod     = period;
  PWM[channelNum].newDutyCycle  = dutycycle;
  PWM[channelNum].newOnTime     = ( period * dutycycle ) / 100;

  PWM_LOGINFO0("Channel : ");
  PWM_LOGINFO0(channelNum);
  PWM_LOGINFO0("\t    Period : ");
  PWM_LOGINFO0(period);
  PWM_LOGINFO0("\t\tOnTime : ");
  PWM_LOGINFO0(PWM[channelNum].newOnTime);
  PWM_LOGINFO0("\tStart_Time : ");
  PWM_LOGINFOLN0(PWM[channelNum].prevTime);

#else

  PWM[channelNum].period        = period;

  PWM[channelNum].onTime        = ( period * dutycycle ) / 100;

  digitalWrite(pin, HIGH);
  PWM[channelNum].pinHigh       = true;

  PWM[channelNum].prevTime      = timeNow();

  PWM_LOGINFO0("Channel : ");
  PWM_LOGINFO0(channelNum);
  PWM_LOGINFO0("\t    Period : ");
  PWM_LOGINFO0(PWM[channelNum].period);
  PWM_LOGINFO0("\t\tOnTime : ");
  PWM_LOGINFO0(PWM[channelNum].onTime);
  PWM_LOGINFO0("\tStart_Time : ");
  PWM_LOGINFOLN0(PWM[channelNum].prevTime);

#endif


  return true;
}


///////////////////////////////////////////////////

void ESP8266_PWM_ISR::deleteChannel(const uint8_t& channelNum)
{
  // nothing to delete if no timers are in use
  if ( (channelNum >= MAX_NUMBER_CHANNELS) || (numChannels == 0) )
  {
    return;
  }

  // don't decrease the number of timers if the specified slot is already empty (zero period, invalid)
  if ( (PWM[channelNum].pin != INVALID_ESP8266_PIN) && (PWM[channelNum].period != 0) )
  {
    memset((void*) &PWM[channelNum], 0, sizeof (PWM_t));

    PWM[channelNum].pin = INVALID_ESP8266_PIN;

    // update number of timers
    numChannels--;
  }
}

///////////////////////////////////////////////////

void ESP8266_PWM_ISR::restartChannel(const uint8_t& channelNum)
{
  if (channelNum >= MAX_NUMBER_CHANNELS)
  {
    return;
  }

  PWM[channelNum].prevTime = timeNow();
}

///////////////////////////////////////////////////

bool ESP8266_PWM_ISR::isEnabled(const uint8_t& channelNum)
{
  if (channelNum >= MAX_NUMBER_CHANNELS)
  {
    return false;
  }

  return PWM[channelNum].enabled;
}

///////////////////////////////////////////////////

void ESP8266_PWM_ISR::enable(const uint8_t& channelNum)
{
  if (channelNum >= MAX_NUMBER_CHANNELS)
  {
    return;
  }

  PWM[channelNum].enabled = true;
}

///////////////////////////////////////////////////

void ESP8266_PWM_ISR::disable(const uint8_t& channelNum)
{
  if (channelNum >= MAX_NUMBER_CHANNELS)
  {
    return;
  }

  PWM[channelNum].enabled = false;
}

///////////////////////////////////////////////////

void ESP8266_PWM_ISR::enableAll()
{
  // Enable all timers with a callback assigned (used)

  for (uint8_t channelNum = 0; channelNum < MAX_NUMBER_CHANNELS; channelNum++)
  {
    if (PWM[channelNum].period != 0)
    {
      PWM[channelNum].enabled = true;
    }
  }
}

///////////////////////////////////////////////////

void ESP8266_PWM_ISR::disableAll()
{
  // Disable all timers with a callback assigned (used)

  for (uint8_t channelNum = 0; channelNum < MAX_NUMBER_CHANNELS; channelNum++)
  {
    if (PWM[channelNum].period != 0)
    {
      PWM[channelNum].enabled = false;
    }
  }
}

///////////////////////////////////////////////////

void ESP8266_PWM_ISR::toggle(const uint8_t& channelNum)
{
  if (channelNum >= MAX_NUMBER_CHANNELS)
  {
    return;
  }

  PWM[channelNum].enabled = !PWM[channelNum].enabled;
}

///////////////////////////////////////////////////

int8_t ESP8266_PWM_ISR::getnumChannels()
{
  return numChannels;
}


#endif    // PWM_ISR_GENERIC_IMPL_H

